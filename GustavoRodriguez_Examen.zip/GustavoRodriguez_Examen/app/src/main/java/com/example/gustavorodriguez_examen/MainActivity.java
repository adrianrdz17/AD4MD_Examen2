package com.example.gustavorodriguez_examen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

public class MainActivity extends Activity {

    Button btnMostrar;
    EditText etDimension;
    TableLayout tl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnMostrar = findViewById(R.id.xbtnMostrar);
        etDimension = findViewById(R.id.xetDimension);

        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String handler = etDimension.getText().toString();
                int n = Integer.parseInt(handler);

                if (n%2 == 0){
                    Toast.makeText(this, "Ingrese un numero natural impar", Toast.LENGTH_SHORT).show();
                } else {

                }

            }
        });

    }
}